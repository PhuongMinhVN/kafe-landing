=====================================================================
          PMVN SMART CAFE SUITE - BAN PORTABLE (1-CLICK)
             Chu Gia Security / PMVN Software
                    Hotline / Zalo: 0941.204.125
=====================================================================

1. CACH CHAY (KHONG CAN CAI DAT NODE.JS HAY PHAN MEM PHU):
   - Copy toan bo thu muc PMVN-Cafe-Portable sang bat ky may Windows nao
     (O D:, Desktop, hoac chay truc tiep tren USB).
   - Nhap dup chuot vao file:
         >>>  RunCafe.exe  <<<   (hoac RunCafe.bat)
   - Phan mem tu dong tao bieu tuong "PMVN Cafe POS" ngoai Desktop va
     mo giao dien tai: http://localhost:3001/pos

2. KET NOI DIEN THOAI / IPAD / MAY TINH BANG CUNG MANG WI-FI:
   - Lan dau cai tren may thu ngan, bam dup (hoac chuot phai Run as administrator)
     vao file:
         >>>  Mo-Cong-LAN.bat  <<<
     de tu dong mo tuong lua cong 3001 va hien san duong link (vd: http://192.168.1.100:3001).
   - Nhan vien phuc vu mo link do tren dien thoai, dang nhap phucvu / pmvn1234.
   - Khach quet ma QR tai ban (/qr) de goi mon truc tiep ve quay.

3. TAI KHOAN DANG NHAP MAC DINH:
   - Chu quan:  admin    / pmvn1234
   - Thu ngan:  thungan  / pmvn1234
   - Pha che:   phache   / pmvn1234
   - Phuc vu:   phucvu   / pmvn1234
   (Vui long doi mat khau trong muc Cai Dat sau khi dang nhap lan dau.)

4. SAO LUU & CHUYEN MAY:
   - Toan bo du lieu ban, thuc don, kho, hoa don, ca lam viec nam tai:
         Data\cafe.db
   - Chi can copy thu muc Data la giu nguyen 100% du lieu khi chuyen may.
=====================================================================
