@echo off
chcp 65001 >nul
title PMVN Cafe POS - Mo cong LAN (Port 3001) cho dien thoai / iPad

net session >nul 2>&1
if %errorlevel% EQU 0 goto :ADMIN_OK

echo [*] Dang yeu cau quyen Administrator de mo Windows Firewall...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b 0

:ADMIN_OK
set "BASE_DIR=%~dp0"
if "%BASE_DIR:~-1%"=="\" set "BASE_DIR=%BASE_DIR:~0,-1%"
set "NODE_BIN=%BASE_DIR%\_core\node.exe"

echo.
echo =====================================================================
echo        PMVN SMART CAFE SUITE - MO CONG LAN (PORT 3001)
echo =====================================================================
echo.

echo [1/2] Dang mo tuong lua Windows Firewall cho cong TCP 3001...
netsh advfirewall firewall delete rule name="PMVN Cafe POS (Port 3001)" >nul 2>&1
netsh advfirewall firewall add rule name="PMVN Cafe POS (Port 3001)" dir=in action=allow protocol=TCP localport=3001 profile=any >nul
if %errorlevel% EQU 0 (
    echo [OK] Da mo cong TCP 3001 thanh cong - ap dung cho moi mang Wi-Fi va LAN!
) else (
    echo [X] Khong the mo cong 3001 trong Windows Firewall.
)

if exist "%NODE_BIN%" (
    netsh advfirewall firewall delete rule name="PMVN Cafe Node Runtime" >nul 2>&1
    netsh advfirewall firewall add rule name="PMVN Cafe Node Runtime" dir=in action=allow program="%NODE_BIN%" profile=any >nul 2>&1
    echo [OK] Da cho phep _core\node.exe ket noi mang LAN!
)

echo.
echo [2/2] Dia chi ket noi cho dien thoai / iPad cung mang Wi-Fi:
echo ---------------------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' -and $_.PrefixOrigin -ne 'WellKnown' -and $_.InterfaceAlias -notlike '*vEthernet*' -and $_.InterfaceAlias -notlike '*WSL*' -and $_.InterfaceAlias -notlike '*Docker*' } | Select-Object -ExpandProperty IPAddress -Unique; if (-not $ips) { Write-Host '   (Chua tim thay IP mang LAN - kiem tra Wi-Fi/day mang)' -ForegroundColor Yellow } else { foreach ($ip in $ips) { Write-Host ('   >>>  http://' + $ip + ':3001          (Trang chinh / POS)') -ForegroundColor Green; Write-Host ('        http://' + $ip + ':3001/tables   (So do ban phuc vu)') -ForegroundColor Cyan; Write-Host ('        http://' + $ip + ':3001/qr       (In ma QR tung ban)') -ForegroundColor Gray; Write-Host '' } }"
echo ---------------------------------------------------------------------
echo.
echo HUONG DAN NHAN VIEN PHUC VU:
echo   1. Bat chung Wi-Fi voi may thu ngan nay (nho mo RunCafe.exe truoc).
echo   2. Mo Chrome (Android) hoac Safari (iPhone) - go dia chi mau xanh o tren.
echo   3. Dang nhap:  phucvu / pmvn1234   (hoac phache / pmvn1234)
echo   4. Chon "Them vao Man hinh chinh" de dung nhu ung dung rieng.
echo.
echo =====================================================================
echo.
pause
exit /b 0
