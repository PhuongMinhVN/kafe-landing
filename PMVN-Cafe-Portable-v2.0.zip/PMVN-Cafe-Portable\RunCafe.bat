@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
title PMVN Smart Cafe Suite - Barista Studio POS Launcher

:: 1. Xac dinh duong dan tuong doi (chay duoc du copy sang bat ky o dia / may tinh nao)
set "BASE_DIR=%~dp0"
if "%BASE_DIR:~-1%"=="\" set "BASE_DIR=%BASE_DIR:~0,-1%"

:: Neu co RunCafe.exe (co man hinh Intro Barista Studio) thi goi truc tiep file .exe
if exist "%BASE_DIR%\RunCafe.exe" (
    start "" "%BASE_DIR%\RunCafe.exe"
    exit /b 0
)

set "CORE_DIR=%BASE_DIR%\_core"
set "APP_DIR=%CORE_DIR%\app"
set "DATA_DIR=%BASE_DIR%\Data"
set "NODE_BIN=%CORE_DIR%\node.exe"
set "DB_FILE=%DATA_DIR%\cafe.db"
set "TEMPLATE_DB=%CORE_DIR%\data-template.sqlite"
set "ICON_FILE=%CORE_DIR%\pmvn.ico"
set "APP_URL=http://localhost:3001/pos"
set "HEALTH_URL=http://127.0.0.1:3001/api/v1/license"

if not exist "%NODE_BIN%" (
    echo [X] LOI: Khong tim thay _core\node.exe!
    echo     Vui long giu nguyen thu muc _core cung cap voi RunCafe.
    pause
    exit /b 1
)
if not exist "%APP_DIR%\server.js" (
    echo [X] LOI: Khong tim thay _core\app\server.js!
    pause
    exit /b 1
)

:: 2. Khoi tao CSDL Data\cafe.db neu chua co (giu nguyen du lieu + ban quyen neu da co)
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%" >nul 2>&1
if not exist "%DB_FILE%" (
    if exist "%TEMPLATE_DB%" (
        copy /Y "%TEMPLATE_DB%" "%DB_FILE%" >nul
    )
)

set "DB_URL_PATH=%DB_FILE:\=/%"
set "DATABASE_URL=file:%DB_URL_PATH%"
set "NODE_ENV=production"
set "PORT=3001"
set "HOSTNAME=::"

:: 3. Tu dong tao Desktop Shortcut "PMVN Cafe POS" ngoai man hinh Desktop
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desk = [Environment]::GetFolderPath('Desktop'); $lnk = Join-Path $desk 'PMVN Cafe POS.lnk'; $s = $ws.CreateShortcut($lnk); $exe = Join-Path $env:BASE_DIR 'RunCafe.exe'; $s.TargetPath = if (Test-Path $exe) { $exe } else { Join-Path $env:BASE_DIR 'RunCafe.bat' }; $s.WorkingDirectory = $env:BASE_DIR; if (Test-Path $env:ICON_FILE) { $s.IconLocation = $env:ICON_FILE + ',0' }; $s.Description = 'PMVN Smart Cafe Suite - Barista Studio POS'; $s.Save()" >nul 2>&1

:: 4. Giai phong cong 3001 de tranh xung dot ban cu
echo [*] Dang giai phong cong 3001...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -LocalPort 3001 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique | Where-Object { $_ -gt 0 } | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }" >nul 2>&1
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":3001 .*LISTENING"') do (
    if not "%%P"=="0" taskkill /PID %%P /F >nul 2>&1
)
powershell -NoProfile -Command "Start-Sleep -Milliseconds 500" >nul 2>&1

:: 5. Khoi chay Node.js Server Backend ngam (Hidden)
echo [*] Dang khoi dong PMVN Cafe Server tren cong 3001...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:NODE_BIN -ArgumentList 'server.js' -WorkingDirectory $env:APP_DIR -WindowStyle Hidden"

:: Doi Server san sang qua 127.0.0.1
set "SERVER_READY=0"
for /l %%i in (1,1,20) do (
    powershell -NoProfile -Command "try { $r = Invoke-WebRequest -Uri $env:HEALTH_URL -UseBasicParsing -TimeoutSec 2; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
    if not errorlevel 1 (
        set "SERVER_READY=1"
        goto LAUNCH_PWA
    )
    timeout /t 1 /nobreak >nul
)

if "%SERVER_READY%"=="0" (
    echo [X] Khong the khoi dong may chu noi bo tren cong 3001.
    echo     Vui long kiem tra lai phan mem diet virus hoac quyen truy cap.
    pause
    exit /b 1
)

:LAUNCH_PWA
:: 6. Mo giao dien o che do Cua So Ung Dung PWA doc lap (--app=http://localhost:3001/pos)
set "BROWSER_BIN="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER_BIN=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if "%BROWSER_BIN%"=="" if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BROWSER_BIN=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if "%BROWSER_BIN%"=="" if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BROWSER_BIN=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if "%BROWSER_BIN%"=="" if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BROWSER_BIN=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if "%BROWSER_BIN%"=="" if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BROWSER_BIN=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if not "%BROWSER_BIN%"=="" (
    start "" "%BROWSER_BIN%" --app=%APP_URL% --window-size=1440,900
) else (
    start "" "%APP_URL%"
)
exit /b 0
